"use client"

import { useEffect, useState } from "react"
import { getMotivationalMessage } from "@/ai/flows/ai-motivational-coach"
import { Sparkles, X, BrainCircuit, Quote, Loader2, ChevronRight, MessageSquare, Maximize2, Minimize2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface AICoachPanelProps {
  explanation?: string
  onCloseExplanation?: () => void
}

export function AICoachPanel({ explanation, onCloseExplanation }: AICoachPanelProps) {
  const [motivation, setMotivation] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const fetchMotivation = async () => {
      setIsLoading(true)
      try {
        const res = await getMotivationalMessage()
        setMotivation(res.message)
      } catch (err) {
        setMotivation("Focus on the geometric patterns. Each deduction brings you closer to mental clarity.")
      } finally {
        setIsLoading(false)
      }
    }
    fetchMotivation()
    const interval = setInterval(fetchMotivation, 300000)
    return () => clearInterval(interval)
  }, [])

  return (
    <>
      {/* 
          LAYER 1: LOGIC SYNTHESIS (Explanations & Hints)
          Positioned on the Left to ensure it NEVER overlaps with the Insight Bubble.
          This system is fully independent of the Insight Bubble's state.
      */}
      {explanation && (
        <div className="fixed bottom-6 left-6 z-[60] flex flex-col items-start gap-4 w-full max-w-sm pointer-events-none">
          <div className="glass-card p-8 rounded-[2.5rem] border-primary/20 pointer-events-auto w-full animate-in slide-in-from-left-8 fade-in duration-700 shadow-[0_20px_60px_rgba(0,0,0,0.6)] bg-primary/[0.02]">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-primary/10 text-primary shadow-inner">
                  <BrainCircuit className="w-5 h-5" />
                </div>
                <div className="space-y-0.5">
                  <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-primary/80">Neural Synthesis</span>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full hover:bg-white/5 opacity-50 hover:opacity-100 transition-all" 
                onClick={onCloseExplanation}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <ScrollArea className="max-h-60 pr-4">
              <p className="text-xl leading-relaxed text-foreground/90 font-medium font-headline tracking-tight">
                {explanation}
              </p>
            </ScrollArea>
            <div className="mt-8 flex items-center gap-2 text-[9px] font-bold uppercase tracking-[0.2em] text-muted-foreground/40">
              <div className="w-1 h-1 rounded-full bg-primary animate-pulse" />
              Real-time Logic Stream
            </div>
          </div>
        </div>
      )}

      {/* 
          LAYER 2: MINDUKU INSIGHT (Motivational Bubble)
          Floating corner widget that is minimizable and closable.
      */}
      {!isVisible ? (
        <div className="fixed bottom-6 right-6 z-50 pointer-events-auto animate-in fade-in zoom-in duration-700">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => setIsVisible(true)}
            className="h-14 w-14 rounded-full glass border-primary/20 bg-primary/5 text-primary shadow-2xl hover:bg-primary/10 transition-all hover:scale-110 active:scale-95"
          >
            <Sparkles className="w-6 h-6" />
          </Button>
        </div>
      ) : (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-4 w-full max-w-xs pointer-events-none">
          <div className={cn(
            "glass rounded-[2.5rem] border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.4)] pointer-events-auto transition-all duration-700 ease-apple-ease relative overflow-hidden group",
            isMinimized ? "w-16 h-16 p-0 rounded-full" : "w-full p-6"
          )}>
            {isMinimized ? (
              <button 
                onClick={() => setIsMinimized(false)}
                className="w-full h-full flex items-center justify-center text-primary relative group"
              >
                <div className="absolute inset-0 bg-primary/5 animate-pulse group-hover:bg-primary/10 transition-colors" />
                <Sparkles className="w-6 h-6 relative z-10 transition-transform group-hover:rotate-12" />
              </button>
            ) : (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-primary">
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Quote className="w-4 h-4 opacity-50" />}
                    <span className="text-[9px] uppercase tracking-[0.3em] font-bold text-muted-foreground/60">Mindoku Insight</span>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 rounded-lg hover:bg-white/5 text-muted-foreground"
                      onClick={() => setIsMinimized(true)}
                    >
                      <Minimize2 className="h-3.5 w-3.5" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 rounded-lg hover:bg-white/5 text-muted-foreground"
                      onClick={() => setIsVisible(false)}
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
                
                <p className="text-[13px] text-foreground/80 leading-relaxed font-medium">
                  {isLoading && !motivation ? "Synthesizing neural patterns..." : motivation || "Focus builds clarity."}
                </p>

                {isLoading && (
                  <div className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-white/5">
                    <div className="h-full bg-primary animate-[shimmer_2s_infinite]" style={{ width: '30%' }} />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  )
}
