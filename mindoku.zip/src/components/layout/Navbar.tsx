
"use client"

import { Button } from "@/components/ui/button"
import { Crown, ChevronDown, Timer } from "lucide-react"
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { Difficulty } from "@/lib/sudoku-utils"

interface NavbarProps {
  view: 'dashboard' | 'game' | 'onboarding'
  difficulty?: Difficulty
  timer?: number
  progress?: number
  onDifficultyChange?: (diff: Difficulty) => void
  onUpgradeClick?: () => void
}

export function Navbar({ 
  view, 
  difficulty, 
  timer, 
  progress = 0,
  onDifficultyChange, 
  onUpgradeClick 
}: NavbarProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass h-20 px-8 flex items-center justify-between border-b-0">
      <div className="flex items-center gap-4 min-w-[200px]">
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary to-blue-400 flex items-center justify-center shadow-lg shadow-primary/20">
          <span className="font-headline font-bold text-white text-xl">M</span>
        </div>
        <span className="font-headline font-bold text-2xl tracking-tighter hidden sm:inline-block text-gradient">Mindoku</span>
      </div>

      {view === 'game' && difficulty && timer !== undefined && (
        <div className="flex-1 flex items-center justify-center gap-12 animate-in fade-in slide-in-from-top-4 duration-1000">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 px-4 py-2 rounded-full hover:bg-white/5 transition-colors group">
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground/60 group-hover:text-primary transition-colors">
                  Difficulty
                </span>
                <span className="text-sm font-bold tracking-tight text-foreground flex items-center">
                  {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                  <ChevronDown className="ml-2 w-3 h-3 opacity-30" />
                </span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="glass border-white/10 rounded-2xl p-2 min-w-[160px]">
              {(['easy', 'medium', 'hard', 'expert'] as Difficulty[]).map((diff) => (
                <DropdownMenuItem 
                  key={diff} 
                  className="rounded-xl px-4 py-2 text-sm font-medium cursor-pointer"
                  onClick={() => onDifficultyChange?.(diff)}
                >
                  {diff.charAt(0).toUpperCase() + diff.slice(1)}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="w-px h-6 bg-white/10" />

          <div className="flex items-center gap-6">
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground/60">Session</span>
              <div className="flex items-center gap-2">
                <Timer className="w-3.5 h-3.5 text-primary opacity-50" />
                <span className="text-sm font-bold font-mono tracking-tight">{formatTime(timer)}</span>
              </div>
            </div>
            
            <div className="flex flex-col items-start w-32 gap-1.5">
              <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-muted-foreground/40">Progress</span>
              <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-1000 ease-apple-ease" 
                  style={{ width: `${progress}%` }} 
                />
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-end gap-6 min-w-[200px]">
        <Button 
          onClick={onUpgradeClick}
          className="apple-button h-10 bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 hidden sm:flex gap-2 px-6"
        >
          <Crown className="w-3.5 h-3.5" />
          <span className="text-[11px] font-bold uppercase tracking-widest">Upgrade</span>
        </Button>

        <div className="w-10 h-10 rounded-full border border-white/10 overflow-hidden cursor-pointer hover:ring-2 ring-primary transition-all p-0.5 bg-white/5">
          <img src="https://picsum.photos/seed/mindoku-user/100/100" alt="Avatar" className="w-full h-full rounded-full object-cover" />
        </div>
      </div>
    </nav>
  )
}
