
"use client"

import { useState, useEffect, useCallback, useMemo, useRef } from "react"
import { Navbar } from "@/components/layout/Navbar"
import { SudokuBoard } from "@/components/sudoku/SudokuBoard"
import { GameControls } from "@/components/sudoku/GameControls"
import { AICoachPanel } from "@/components/ai/AICoachPanel"
import { Onboarding } from "@/components/onboarding/Onboarding"
import { StatsDashboard } from "@/components/dashboard/StatsDashboard"
import { UpgradeModal } from "@/components/pro/UpgradeModal"
import { VictoryReflection } from "@/components/victory/VictoryReflection"
import { generateSudoku, Difficulty, isBoardComplete, getConflicts, getNumberCounts, getSudokuHint, getSudokuExplanation } from "@/lib/sudoku-utils"
import { generateReflection, type AIReflectionOutput } from "@/ai/flows/ai-reflection"
import { useToast } from "@/hooks/use-toast"
import { LayoutDashboard, Gamepad2, Loader2, Sparkles } from "lucide-react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MindokuApp() {
  const [view, setView] = useState<'onboarding' | 'dashboard' | 'game'>('onboarding')
  const [board, setBoard] = useState<number[][]>([])
  const [initialBoard, setInitialBoard] = useState<number[][]>([])
  const [solvedBoard, setSolvedBoard] = useState<number[][]>([])
  const [notes, setNotes] = useState<Set<number>[][]>([])
  const [difficulty, setDifficulty] = useState<Difficulty>('medium')
  const [selectedCell, setSelectedCell] = useState<[number, number] | null>(null)
  const [isNotesMode, setIsNotesMode] = useState(false)
  const [timer, setTimer] = useState(0)
  const [mistakes, setMistakes] = useState(0)
  const [hintsUsed, setHintsUsed] = useState(0)
  const [isGameWon, setIsGameWon] = useState(false)
  const [aiExplanation, setAiExplanation] = useState<string | undefined>()
  const [isProModalOpen, setIsProModalOpen] = useState(false)
  
  const [reflection, setReflection] = useState<AIReflectionOutput | null>(null)
  const [isGeneratingReflection, setIsGeneratingReflection] = useState(false)
  const moveTimestamps = useRef<number[]>([])

  const { toast } = useToast()

  const numberCounts = useMemo(() => {
    if (!board || board.length === 0 || !initialBoard) {
      const empty: Record<number, number> = {};
      for (let i = 1; i <= 9; i++) empty[i] = 0;
      return empty;
    }
    return getNumberCounts(board, initialBoard);
  }, [board, initialBoard]);

  const progress = useMemo(() => {
    if (!board || board.length === 0) return 0;
    const filled = board.flat().filter(n => n !== 0).length;
    return (filled / 81) * 100;
  }, [board]);

  const startNewGame = useCallback((diff: Difficulty = 'medium') => {
    const { initial, solved } = generateSudoku(diff)
    setBoard(initial.map(row => [...row]))
    setInitialBoard(initial.map(row => [...row]))
    setSolvedBoard(solved)
    setNotes(Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => new Set())))
    setTimer(0)
    setMistakes(0)
    setHintsUsed(0)
    setIsGameWon(false)
    setReflection(null)
    setAiExplanation(undefined)
    setSelectedCell(null)
    setDifficulty(diff)
    setView('game')
    moveTimestamps.current = [Date.now()]
  }, [])

  useEffect(() => {
    const hasOnboarded = localStorage.getItem('mindoku_onboarded')
    if (hasOnboarded) setView('dashboard')
  }, [])

  useEffect(() => {
    if (view !== 'game' || isGameWon) return
    const interval = setInterval(() => setTimer(t => t + 1), 1000)
    return () => clearInterval(interval)
  }, [view, isGameWon])

  const handleVictory = useCallback(async () => {
    setIsGameWon(true)
    setIsGeneratingReflection(true)
    
    const intervals: number[] = []
    for (let i = 1; i < moveTimestamps.current.length; i++) {
      intervals.push((moveTimestamps.current[i] - moveTimestamps.current[i-1]) / 1000)
    }
    const avgRhythm = intervals.length > 0 ? intervals.reduce((a, b) => a + b) / intervals.length : 0

    try {
      const res = await generateReflection({
        timeInSeconds: timer,
        mistakes,
        hintsUsed,
        difficulty,
        averageRhythmSeconds: avgRhythm
      })
      setReflection(res)
    } catch (err) {
      console.error(err)
      setReflection({
        archetype: 'The Flow Thinker',
        reflection: 'You demonstrated a calm and consistent cognitive rhythm throughout this session.',
        focusScore: 85,
        insight: 'Patience builds mental endurance.'
      })
    } finally {
      setIsGeneratingReflection(false)
    }
  }, [timer, mistakes, hintsUsed, difficulty])

  const handleNumberInput = (num: number) => {
    if (!selectedCell || isGameWon || !board.length) return
    const [r, c] = selectedCell
    if (initialBoard[r][c] !== 0) return

    if (isNotesMode) {
      const newNotes = [...notes]
      const cellNotes = new Set(newNotes[r][c])
      if (cellNotes.has(num)) cellNotes.delete(num)
      else cellNotes.add(num)
      newNotes[r][c] = cellNotes
      setNotes(newNotes)
    } else {
      const newBoard = board.map(row => [...row])
      newBoard[r][c] = num
      setBoard(newBoard)
      
      moveTimestamps.current.push(Date.now())

      const conflicts = getConflicts(newBoard, r, c, num)
      if (conflicts.length > 0) {
        setMistakes(m => m + 1)
      }

      if (isBoardComplete(newBoard) && getConflicts(newBoard, -1, -1, -1).length === 0) {
        handleVictory()
      }
    }
  }

  if (view === 'onboarding') return <Onboarding onComplete={() => {
    localStorage.setItem('mindoku_onboarded', 'true')
    setView('dashboard')
  }} />

  return (
    <div className="min-h-screen pt-28 pb-12 px-6 max-w-[1400px] mx-auto overflow-x-hidden selection:bg-primary/20">
      <Navbar 
        view={view} 
        difficulty={difficulty} 
        timer={timer} 
        progress={progress}
        onDifficultyChange={startNewGame}
        onUpgradeClick={() => setIsProModalOpen(true)} 
      />
      
      <div className="space-y-16 animate-slide-up">
        <div className="flex justify-center">
          <Tabs value={view} onValueChange={(v) => setView(v as any)} className="glass rounded-full p-1 border-white/5 shadow-2xl">
            <TabsList className="bg-transparent gap-1 h-auto">
              <TabsTrigger value="dashboard" className="rounded-full px-8 py-2.5 data-[state=active]:bg-white data-[state=active]:text-black data-[state=active]:shadow-xl transition-all font-medium">
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Performance
              </TabsTrigger>
              <TabsTrigger value="game" className="rounded-full px-8 py-2.5 data-[state=active]:bg-white data-[state=active]:text-black data-[state=active]:shadow-xl transition-all font-medium">
                <Gamepad2 className="w-4 h-4 mr-2" />
                Training
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {view === 'dashboard' ? (
          <div className="max-w-6xl mx-auto">
            <StatsDashboard />
          </div>
        ) : (
          <div className="flex flex-col items-center">
            <div className="w-full flex justify-center mb-12">
               <div className="flex items-center gap-2 px-6 py-2 rounded-full glass border-primary/10">
                <Sparkles className="w-4 h-4 text-primary animate-pulse" />
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary">Focus Mode Active</span>
              </div>
            </div>

            {board.length > 0 && (
              <SudokuBoard 
                board={board} 
                initialBoard={initialBoard}
                notes={notes}
                selectedCell={selectedCell}
                onCellClick={(r, c) => setSelectedCell([r, c])}
              />
            )}

            {board.length > 0 && (
              <GameControls 
                isNotesMode={isNotesMode}
                onToggleNotes={() => setIsNotesMode(!isNotesMode)}
                onNumberClick={handleNumberInput}
                numberCounts={numberCounts}
                onErase={() => {
                  if (!selectedCell || isGameWon) return
                  const [r, c] = selectedCell
                  if (initialBoard[r][c] !== 0) return
                  const newBoard = board.map(row => [...row])
                  newBoard[r][c] = 0
                  setBoard(newBoard)
                  const newNotes = [...notes]
                  newNotes[r][c] = new Set()
                  setNotes(newNotes)
                }}
                onHint={() => {
                  setHintsUsed(h => h + 1)
                  const hint = getSudokuHint(board, solvedBoard)
                  setAiExplanation(hint)
                  toast({ title: "Logic Hint", description: "Strategic clue synthesized." })
                }}
                onExplain={() => {
                  if (!selectedCell) {
                    toast({ title: "No Cell Selected", description: "Select a cell to analyze its logic." })
                    return
                  }
                  const [r, c] = selectedCell
                  const num = board[r][c]
                  const explanation = getSudokuExplanation(board, r, c, num)
                  setAiExplanation(explanation)
                  toast({ title: "Neural Synthesis", description: "Conflict analysis complete." })
                }}
                onReset={() => startNewGame(difficulty)}
              />
            )}
          </div>
        )}
      </div>

      <AICoachPanel 
        explanation={aiExplanation} 
        onCloseExplanation={() => setAiExplanation(undefined)} 
      />

      <UpgradeModal isOpen={isProModalOpen} onClose={() => setIsProModalOpen(false)} />

      {isGameWon && (
        <VictoryReflection 
          timer={timer}
          mistakes={mistakes}
          difficulty={difficulty}
          reflection={reflection}
          isLoading={isGeneratingReflection}
          onRestart={() => startNewGame(difficulty)}
          onDashboard={() => setView('dashboard')}
        />
      )}
    </div>
  )
}
