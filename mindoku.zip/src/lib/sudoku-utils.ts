/**
 * @fileOverview Sudoku utility functions for game logic, solving, and validation.
 */

export type Difficulty = 'easy' | 'medium' | 'hard' | 'expert';

export function isValid(board: number[][], row: number, col: number, num: number): boolean {
  for (let x = 0; x < 9; x++) {
    if (board[row][x] === num) return false;
  }
  for (let x = 0; x < 9; x++) {
    if (board[x][col] === num) return false;
  }
  const startRow = row - (row % 3);
  const startCol = col - (col % 3);
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (board[i + startRow][j + startCol] === num) return false;
    }
  }
  return true;
}

export function solveSudoku(board: number[][]): boolean {
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      if (board[row][col] === 0) {
        for (let num = 1; num <= 9; num++) {
          if (isValid(board, row, col, num)) {
            board[row][col] = num;
            if (solveSudoku(board)) return true;
            board[row][col] = 0;
          }
        }
        return false;
      }
    }
  }
  return true;
}

export function generateSudoku(difficulty: Difficulty): { initial: number[][]; solved: number[][] } {
  const solved: number[][] = Array.from({ length: 9 }, () => Array(9).fill(0));
  
  for (let i = 0; i < 9; i += 3) {
    fillBlock(solved, i, i);
  }
  
  solveSudoku(solved);
  
  const initial = solved.map(row => [...row]);
  const attempts = {
    easy: 30,
    medium: 45,
    hard: 55,
    expert: 64,
  }[difficulty];

  let removed = 0;
  while (removed < attempts) {
    const r = Math.floor(Math.random() * 9);
    const c = Math.floor(Math.random() * 9);
    if (initial[r][c] !== 0) {
      initial[r][c] = 0;
      removed++;
    }
  }

  return { initial, solved };
}

function fillBlock(board: number[][], row: number, col: number) {
  let num;
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      do {
        num = Math.floor(Math.random() * 9) + 1;
      } while (!isValidBlock(board, row, col, num));
      board[row + i][col + j] = num;
    }
  }
}

function isValidBlock(board: number[][], row: number, col: number, num: number) {
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (board[row + i][col + j] === num) return false;
    }
  }
  return true;
}

export function isBoardComplete(board: number[][]): boolean {
  if (!board || board.length < 9) return false;
  for (let i = 0; i < 9; i++) {
    if (!board[i]) return false;
    for (let j = 0; j < 9; j++) {
      if (board[i][j] === 0) return false;
    }
  }
  return true;
}

export function getConflicts(board: number[][], row: number, col: number, num: number): { row: number, col: number }[] {
  const conflicts: { row: number, col: number }[] = [];
  if (num === 0 || row === -1 || col === -1 || !board || !board[row]) return conflicts;

  for (let x = 0; x < 9; x++) {
    if (x !== col && board[row][x] === num) conflicts.push({ row, col: x });
  }
  for (let x = 0; x < 9; x++) {
    if (x !== row && board[x] && board[x][col] === num) conflicts.push({ row: x, col });
  }
  const startRow = row - (row % 3);
  const startCol = col - (col % 3);
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      const r = i + startRow;
      const c = j + startCol;
      if (board[r] && (r !== row || c !== col) && board[r][c] === num) {
        conflicts.push({ row: r, col: c });
      }
    }
  }
  return conflicts;
}

export function getNumberCounts(board: number[][], initialBoard: number[][]): Record<number, number> {
  const counts: Record<number, number> = {};
  for (let n = 1; n <= 9; n++) counts[n] = 0;
  
  if (!board || board.length < 9 || !initialBoard) return counts;

  for (let r = 0; r < 9; r++) {
    if (!board[r]) continue;
    for (let c = 0; c < 9; c++) {
      const val = board[r][c];
      if (val !== 0) {
        // Count it if it matches the solved board OR if it's initial
        // Actually, let's just count all validly placed numbers
        const conflicts = getConflicts(board, r, c, val);
        if (conflicts.length === 0) {
          counts[val]++;
        }
      }
    }
  }
  return counts;
}

export function getCompletedLines(board: number[][]): { rows: boolean[], cols: boolean[], blocks: boolean[] } {
  const rows = new Array(9).fill(false);
  const cols = new Array(9).fill(false);
  const blocks = new Array(9).fill(false);

  if (!board || board.length < 9) return { rows, cols, blocks };

  for (let i = 0; i < 9; i++) {
    if (!board[i]) continue;

    let rowComplete = true;
    let colComplete = true;
    const rowSet = new Set();
    const colSet = new Set();
    
    for (let j = 0; j < 9; j++) {
      if (board[i][j] === 0) rowComplete = false;
      else rowSet.add(board[i][j]);

      if (!board[j] || board[j][i] === 0) colComplete = false;
      else colSet.add(board[j][i]);
    }
    
    if (rowComplete && rowSet.size === 9) rows[i] = true;
    if (colComplete && colSet.size === 9) cols[i] = true;
  }

  for (let b = 0; b < 9; b++) {
    const blockSet = new Set();
    const startRow = Math.floor(b / 3) * 3;
    const startCol = (b % 3) * 3;
    let blockComplete = true;
    
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        const r = startRow + i;
        const c = startCol + j;
        if (!board[r] || board[r][c] === 0) {
          blockComplete = false;
        } else {
          blockSet.add(board[r][c]);
        }
      }
    }
    if (blockComplete && blockSet.size === 9) blocks[b] = true;
  }

  return { rows, cols, blocks };
}

/**
 * Generates a logical Sudoku hint without giving the answer directly.
 */
export function getSudokuHint(board: number[][], solvedBoard: number[][]): string {
  if (!board || !solvedBoard) return "Focus on the areas with the most numbers already filled in.";

  // Find a block that is closest to completion
  const lineStats = getCompletedLines(board);
  const blocks = Array.from({ length: 9 }).map((_, i) => {
    const startRow = Math.floor(i / 3) * 3;
    const startCol = (i % 3) * 3;
    let filled = 0;
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        if (board[startRow + r][startCol + c] !== 0) filled++;
      }
    }
    return { id: i + 1, filled };
  }).filter(b => b.filled < 9).sort((a, b) => b.filled - a.filled);

  if (blocks.length > 0) {
    return `Mindoku Insight: Focus on Block ${blocks[0].id}. It's almost complete, which narrows down the remaining logical candidates significantly.`;
  }

  return "Cognitive Clue: Try checking for 'Hidden Singles' in rows or columns that are more than half-filled.";
}

/**
 * Generates a logical explanation for why a placement might be incorrect.
 */
export function getSudokuExplanation(board: number[][], row: number, col: number, num: number): string {
  if (num === 0) return "Select a cell with a value to analyze its logic.";

  // Check row
  for (let x = 0; x < 9; x++) {
    if (x !== col && board[row][x] === num) {
      return `Logical Conflict: The number ${num} is already present in Row ${row + 1}. A Sudoku row must contain unique digits from 1 to 9.`;
    }
  }

  // Check column
  for (let x = 0; x < 9; x++) {
    if (x !== row && board[x][col] === num) {
      return `Logical Conflict: The number ${num} is already present in Column ${col + 1}. Each column requires a unique set of digits.`;
    }
  }

  // Check block
  const startRow = row - (row % 3);
  const startCol = col - (col % 3);
  const blockId = Math.floor(row / 3) * 3 + Math.floor(col / 3) + 1;
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      const r = i + startRow;
      const c = j + startCol;
      if ((r !== row || c !== col) && board[r][c] === num) {
        return `Logical Conflict: Block ${blockId} already contains the number ${num}. Every 3x3 block must maintain digit uniqueness.`;
      }
    }
  }

  return "Logical Synthesis: No immediate conflicts detected in this cell. The placement is logically consistent with its neighbors.";
}
