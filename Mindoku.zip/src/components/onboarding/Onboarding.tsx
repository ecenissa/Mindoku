"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Brain, Sparkles, Target, Zap, ArrowRight, Loader2 } from "lucide-react"
import { getMotivationalMessage } from "@/ai/flows/ai-motivational-coach"

interface OnboardingProps {
  onComplete: () => void
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(0)
  const [motivation, setMotivation] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    getMotivationalMessage().then(res => {
      setMotivation(res.message)
      setIsLoading(false)
    })
  }, [])

  const steps = [
    {
      title: "Mindoku",
      subtitle: "The Future of Focus",
      description: "A minimalist sanctuary for cognitive training and pattern mastery.",
      icon: <Brain className="w-14 h-14 text-primary" />,
      color: "from-primary/30"
    },
    {
      title: "AI Synthesis",
      subtitle: "Personal Coaching",
      description: motivation || "Real-time logical insights tailored to your unique learning curve.",
      icon: <Sparkles className="w-14 h-14 text-blue-400" />,
      color: "from-blue-500/30"
    },
    {
      title: "Deep Flow",
      subtitle: "Mental Resilience",
      description: "Track your concentration index and unlock the true potential of your mind.",
      icon: <Target className="w-14 h-14 text-purple-400" />,
      color: "from-purple-500/30"
    }
  ]

  const next = () => {
    if (step < steps.length - 1) setStep(step + 1)
    else onComplete()
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background px-6 overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-to-b ${steps[step].color} to-transparent transition-all duration-[2000ms] ease-in-out opacity-20`} />
      
      <div className="max-w-lg w-full text-center space-y-16 animate-slide-up relative z-10">
        <div className="relative inline-block">
          <div className="absolute inset-0 blur-[100px] opacity-30 bg-primary animate-pulse" />
          <div className="relative glass-card p-12 rounded-full inline-flex animate-float shadow-2xl border-white/10">
            {steps[step].icon}
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-[0.5em] font-bold text-primary/80">{steps[step].subtitle}</p>
            <h1 className="text-6xl font-headline font-bold tracking-tighter text-gradient leading-tight">
              {steps[step].title}
            </h1>
          </div>
          <p className="text-muted-foreground text-xl leading-relaxed px-8 font-medium">
            {steps[step].description}
          </p>
        </div>

        <div className="flex flex-col gap-10 items-center">
          <div className="flex gap-3">
            {steps.map((_, i) => (
              <div 
                key={i} 
                className={`h-1.5 rounded-full transition-all duration-700 ease-apple-ease ${i === step ? 'w-12 bg-primary' : 'w-2 bg-white/10'}`} 
              />
            ))}
          </div>
          
          <Button 
            onClick={next}
            disabled={step === 1 && isLoading}
            className="apple-button h-16 w-full max-w-[280px] bg-white text-black hover:bg-white/90 text-lg shadow-2xl shadow-white/10 flex items-center justify-center gap-3"
          >
            {step === 1 && isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Initializing AI
              </>
            ) : (
              <>
                {step === steps.length - 1 ? "Enter Mindoku" : "Continue"}
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
