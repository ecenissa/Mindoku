"use client"

import { Brain, Trophy, Flame, Activity, Star, Clock, Zap, Target, TrendingUp } from "lucide-react"
import { AreaChart, Area, XAxis, ResponsiveContainer, Tooltip } from "recharts"
import { TooltipProvider, Tooltip as UITooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip"

const chartData = [
  { day: "Mon", score: 400 },
  { day: "Tue", score: 320 },
  { day: "Wed", score: 550 },
  { day: "Thu", score: 480 },
  { day: "Fri", score: 620 },
  { day: "Sat", score: 580 },
  { day: "Sun", score: 750 },
]

export function StatsDashboard() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 p-1 animate-slide-up">
      <div className="glass-card p-10 col-span-1 lg:col-span-2 space-y-8">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h3 className="text-2xl font-headline font-bold flex items-center gap-3 tracking-tight">
              <Activity className="w-6 h-6 text-primary" />
              Focus Index
            </h3>
            <p className="text-sm text-muted-foreground">Your cognitive load analysis for this week.</p>
          </div>
          <div className="text-right">
            <span className="text-2xl font-headline font-bold text-primary tracking-tighter">+14.2%</span>
            <p className="text-[10px] uppercase tracking-widest font-bold opacity-40">Efficiency Gain</p>
          </div>
        </div>
        
        <div className="h-[250px] w-full mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="day" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12, fontWeight: 500 }}
                dy={10}
              />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="glass px-4 py-2 rounded-xl border-white/10 shadow-2xl">
                        <p className="text-xs font-bold text-primary">{`${payload[0].value} Focus Pts`}</p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Area 
                type="monotone" 
                dataKey="score" 
                stroke="hsl(var(--primary))" 
                strokeWidth={4}
                fillOpacity={1} 
                fill="url(#colorScore)" 
                animationDuration={2000}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8">
        <div className="glass-card p-10 flex flex-col justify-between bg-gradient-to-br from-orange-500/10 to-transparent">
          <div className="space-y-2">
            <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-bold">Mental Streak</p>
            <h4 className="text-6xl font-headline font-bold tracking-tighter">14</h4>
            <p className="text-sm text-muted-foreground">Days of consistency</p>
          </div>
          <div className="flex items-center gap-2 text-orange-400 mt-4 bg-orange-400/10 w-fit px-3 py-1 rounded-full">
            <Flame className="w-4 h-4" />
            <span className="text-xs font-bold">Unstoppable</span>
          </div>
        </div>

        <div className="glass-card p-10 flex flex-col justify-between bg-gradient-to-br from-primary/10 to-transparent">
          <div className="space-y-2">
            <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-bold">Peak Performance</p>
            <h4 className="text-6xl font-headline font-bold tracking-tighter">98%</h4>
            <p className="text-sm text-muted-foreground">Accuracy retention</p>
          </div>
          <div className="flex items-center gap-2 text-primary mt-4 bg-primary/10 w-fit px-3 py-1 rounded-full">
            <TrendingUp className="w-4 h-4" />
            <span className="text-xs font-bold">Global Top 2%</span>
          </div>
        </div>
      </div>

      <div className="glass-card p-10 lg:col-span-4 space-y-10">
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-headline font-bold tracking-tight">Mastery Badges</h3>
          <p className="text-sm text-muted-foreground">4/12 Unlocked</p>
        </div>
        <TooltipProvider>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-6">
            {[
              { icon: <Star className="w-6 h-6" />, label: "Early Bird", active: true, desc: "Solve a puzzle before 8 AM" },
              { icon: <Zap className="w-6 h-6" />, label: "Speedster", active: true, desc: "Complete in under 3 minutes" },
              { icon: <Target className="w-6 h-6" />, label: "Precision", active: true, desc: "Zero mistakes in a Hard puzzle" },
              { icon: <Clock className="w-6 h-6" />, label: "Dedication", active: true, desc: "7-day play streak" },
              { icon: <Brain className="w-6 h-6" />, label: "Logician", active: false, desc: "Complete 50 puzzles" },
              { icon: <Trophy className="w-6 h-6" />, label: "Grandmaster", active: false, desc: "Solve 10 Expert puzzles" },
            ].map((badge, i) => (
              <UITooltip key={i}>
                <TooltipTrigger asChild>
                  <div 
                    className={`flex flex-col items-center gap-4 p-6 rounded-[2.5rem] transition-all duration-700 cursor-help ${badge.active ? 'bg-white/5 opacity-100 hover:bg-white/10 hover:scale-105' : 'opacity-10 grayscale'}`}
                  >
                    <div className={`p-4 rounded-2xl ${badge.active ? 'bg-primary/20 text-primary shadow-lg shadow-primary/20' : 'bg-white/5'}`}>
                      {badge.icon}
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-center leading-tight">{badge.label}</span>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="glass border-white/10 px-4 py-2">
                  <p className="text-xs font-medium">{badge.desc}</p>
                </TooltipContent>
              </UITooltip>
            ))}
          </div>
        </TooltipProvider>
      </div>
    </div>
  )
}
