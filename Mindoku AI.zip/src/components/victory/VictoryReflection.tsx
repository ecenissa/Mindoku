"use client"

import { Button } from "@/components/ui/button"
import { Trophy, ArrowRight, Loader2, Brain, Target, Zap, Clock, Star, Sparkles, Activity } from "lucide-react"
import type { AIReflectionOutput } from "@/ai/flows/ai-reflection"
import { cn } from "@/lib/utils"

interface VictoryReflectionProps {
  timer: number
  mistakes: number
  difficulty: string
  reflection: AIReflectionOutput | null
  isLoading: boolean
  onRestart: () => void
  onDashboard: () => void
}

export function VictoryReflection({
  timer,
  mistakes,
  difficulty,
  reflection,
  isLoading,
  onRestart,
  onDashboard
}: VictoryReflectionProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const archetypeIcons: Record<string, React.ReactNode> = {
    'The Strategist': <Target className="w-8 h-8" />,
    'The Analyst': <Brain className="w-8 h-8" />,
    'The Visionary': <Zap className="w-8 h-8" />,
    'The Flow Thinker': <Activity className="w-8 h-8" />,
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-3xl animate-in fade-in duration-1000 overflow-y-auto py-12 px-6">
      <div className="max-w-4xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        
        {/* Left Side: Reflection Card */}
        <div className="space-y-8 animate-slide-up">
          <div className="relative">
            <div className="absolute -top-24 -left-24 w-64 h-64 bg-primary/20 rounded-full blur-[100px] animate-pulse" />
            <div className="glass-card p-12 relative z-10 border-white/10 shadow-[0_40px_100px_rgba(0,0,0,0.4)] overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <Sparkles className="w-32 h-32" />
              </div>

              {isLoading ? (
                <div className="py-24 flex flex-col items-center justify-center space-y-6">
                  <Loader2 className="w-12 h-12 text-primary animate-spin" />
                  <p className="text-[10px] uppercase tracking-[0.4em] font-bold text-muted-foreground animate-pulse">
                    Synthesizing Focus Patterns...
                  </p>
                </div>
              ) : reflection ? (
                <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-1000">
                  <div className="space-y-4">
                    <div className="flex items-center gap-4 text-primary">
                      <div className="p-3 rounded-2xl bg-primary/10">
                        {archetypeIcons[reflection.archetype] || <Star className="w-8 h-8" />}
                      </div>
                      <span className="text-[10px] uppercase tracking-[0.4em] font-bold">Cognitive Archetype</span>
                    </div>
                    <h2 className="text-5xl font-headline font-bold tracking-tighter text-gradient leading-tight">
                      {reflection.archetype}
                    </h2>
                  </div>

                  <p className="text-xl text-foreground/80 leading-relaxed font-medium italic">
                    "{reflection.reflection}"
                  </p>

                  <div className="p-6 rounded-[1.5rem] bg-white/[0.03] border border-white/5 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Focus Index</span>
                      <span className="text-xl font-headline font-bold text-primary">{reflection.focusScore}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary transition-all duration-[2000ms] ease-apple-ease" 
                        style={{ width: `${reflection.focusScore}%` }} 
                      />
                    </div>
                  </div>

                  <p className="text-sm text-primary/80 font-bold uppercase tracking-widest flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Growth Insight: {reflection.insight}
                  </p>
                </div>
              ) : (
                <div className="py-24 text-center space-y-4">
                  <p className="text-muted-foreground">Failed to analyze session logic.</p>
                  <Button variant="ghost" onClick={() => window.location.reload()}>Retry Analysis</Button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Stats & Actions */}
        <div className="space-y-12 animate-slide-up" style={{ animationDelay: '200ms' }}>
          <div className="space-y-2">
            <h1 className="text-4xl font-headline font-bold tracking-tighter text-gradient">Session Mastered</h1>
            <p className="text-muted-foreground font-medium text-lg">Your neural efficiency is within the top 2% of the Mindoku community.</p>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="glass p-8 rounded-[2rem] border-white/5 group hover:bg-white/[0.04] transition-all">
              <Clock className="w-5 h-5 text-primary mb-3 opacity-40 group-hover:opacity-100 transition-opacity" />
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-bold mb-1">Duration</p>
              <p className="text-3xl font-headline font-bold text-primary tracking-tight">{formatTime(timer)}</p>
            </div>
            <div className="glass p-8 rounded-[2rem] border-white/5 group hover:bg-white/[0.04] transition-all">
              <Activity className="w-5 h-5 text-primary mb-3 opacity-40 group-hover:opacity-100 transition-opacity" />
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-bold mb-1">Accuracy</p>
              <p className="text-3xl font-headline font-bold text-primary tracking-tight">{Math.max(0, 100 - (mistakes * 5))}%</p>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <Button size="lg" className="w-full apple-button bg-white text-black font-bold h-16 text-xl hover:scale-[1.02] shadow-2xl transition-all" onClick={onRestart}>
              Next Challenge
              <ArrowRight className="ml-3 w-6 h-6" />
            </Button>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="ghost" className="apple-button h-14 text-muted-foreground font-bold hover:text-white hover:bg-white/5" onClick={onDashboard}>
                View Analytics
              </Button>
              <Button variant="ghost" className="apple-button h-14 text-primary font-bold hover:bg-primary/10 border border-primary/20">
                Share Reflection
              </Button>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}
