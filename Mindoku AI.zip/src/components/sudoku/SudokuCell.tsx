"use client"

import { cn } from "@/lib/utils"

interface SudokuCellProps {
  value: number
  isInitial: boolean
  isSelected: boolean
  isRelated: boolean
  isConflict: boolean
  isSameNumber: boolean
  isSuccess?: boolean
  notes: Set<number>
  onClick: () => void
}

export function SudokuCell({
  value,
  isInitial,
  isSelected,
  isRelated,
  isConflict,
  isSameNumber,
  isSuccess,
  notes,
  onClick,
}: SudokuCellProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "sudoku-cell",
        // Base layer: Line/Block success state
        isSuccess && "sudoku-cell-line-success",
        
        // Contextual layer: Related crosshair (lowest priority)
        isRelated && !isSelected && "sudoku-cell-related",
        
        // Pattern recognition layer: Matching numbers across the entire board
        // This is unified for all cell types (initial, editable, and success lines)
        isSameNumber && !isSelected && "sudoku-cell-same",
        
        // Active focus layer: The currently selected cell
        isSelected && "sudoku-cell-selected",
        
        // Validation layer: Errors/Conflicts (highest priority)
        isConflict && "sudoku-cell-conflict",
        
        // Text styling based on cell origin
        isInitial ? "text-white font-bold" : "text-primary/90",
        
        "font-headline select-none active:scale-95 transition-transform"
      )}
    >
      {value !== 0 ? (
        <span className="animate-in fade-in zoom-in duration-300">{value}</span>
      ) : (
        <div className="grid grid-cols-3 gap-0.5 w-full h-full p-1.5 opacity-40">
          {Array.from({ length: 9 }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "flex items-center justify-center text-[9px] leading-none transition-all duration-300",
                notes.has(i + 1) ? "opacity-100 scale-100" : "opacity-0 scale-50"
              )}
            >
              {i + 1}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}