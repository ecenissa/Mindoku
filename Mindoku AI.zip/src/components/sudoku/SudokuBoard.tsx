"use client"

import { cn } from "@/lib/utils"
import { SudokuCell } from "./SudokuCell"
import { getConflicts, getCompletedLines } from "@/lib/sudoku-utils"

interface SudokuBoardProps {
  board: number[][]
  initialBoard: number[][]
  notes: Set<number>[][]
  selectedCell: [number, number] | null
  onCellClick: (row: number, col: number) => void
}

export function SudokuBoard({
  board,
  initialBoard,
  notes,
  selectedCell,
  onCellClick,
}: SudokuBoardProps) {
  const lineStats = getCompletedLines(board);

  const isRelated = (r: number, c: number) => {
    if (!selectedCell) return false
    const [sr, sc] = selectedCell
    return r === sr || c === sc || (Math.floor(r / 3) === Math.floor(sr / 3) && Math.floor(c / 3) === Math.floor(sc / 3))
  }

  const hasConflict = (r: number, c: number) => {
    if (board[r][c] === 0) return false
    return getConflicts(board, r, c, board[r][c]).length > 0
  }

  const isSameNumber = (r: number, c: number) => {
    if (!selectedCell) return false
    const [sr, sc] = selectedCell
    const selectedVal = board[sr][sc]
    return selectedVal !== 0 && board[r][c] === selectedVal && (r !== sr || c !== sc)
  }

  const isCellInSuccessLine = (r: number, c: number) => {
    const blockIdx = Math.floor(r / 3) * 3 + Math.floor(c / 3);
    return lineStats.rows[r] || lineStats.cols[c] || lineStats.blocks[blockIdx];
  }

  return (
    <div className="relative glass-card p-1 sm:p-2 w-full max-w-[500px] mx-auto group shadow-2xl">
      <div className="sudoku-grid">
        {board.map((row, rIdx) =>
          row.map((val, cIdx) => (
            <div
              key={`${rIdx}-${cIdx}`}
              className={cn(
                "relative",
                rIdx % 3 === 2 && rIdx !== 8 && "border-b-[1.5px] border-white/20",
                cIdx % 3 === 2 && cIdx !== 8 && "border-r-[1.5px] border-white/20"
              )}
            >
              <SudokuCell
                value={val}
                isInitial={initialBoard[rIdx][cIdx] !== 0}
                isSelected={selectedCell?.[0] === rIdx && selectedCell?.[1] === cIdx}
                isRelated={isRelated(rIdx, cIdx)}
                isConflict={hasConflict(rIdx, cIdx)}
                isSameNumber={isSameNumber(rIdx, cIdx)}
                isSuccess={isCellInSuccessLine(rIdx, cIdx)}
                notes={notes[rIdx][cIdx]}
                onClick={() => onCellClick(rIdx, cIdx)}
              />
            </div>
          ))
        )}
      </div>
    </div>
  )
}
