"use client"

import { Button } from "@/components/ui/button"
import { Pencil, Eraser, Sparkles, Lightbulb, Check } from "lucide-react"
import { cn } from "@/lib/utils"

interface GameControlsProps {
  isNotesMode: boolean
  onToggleNotes: () => void
  onNumberClick: (num: number) => void
  onErase: () => void
  onHint: () => void
  onExplain: () => void
  onReset: () => void
  numberCounts: Record<number, number>
}

export function GameControls({
  isNotesMode,
  onToggleNotes,
  onNumberClick,
  onErase,
  onHint,
  onExplain,
  onReset,
  numberCounts,
}: GameControlsProps) {
  return (
    <div className="flex flex-col gap-8 w-full max-w-[500px] mx-auto mt-10">
      <div className="grid grid-cols-9 gap-2">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => {
          const isCompleted = numberCounts[num] >= 9;
          return (
            <Button
              key={num}
              variant="outline"
              disabled={isCompleted}
              className={cn(
                "h-14 w-full glass rounded-2xl text-2xl font-headline transition-all duration-300 relative",
                isCompleted 
                  ? "opacity-20 scale-90 cursor-default bg-transparent" 
                  : "hover:bg-primary/20 hover:text-primary hover:scale-105 active:scale-95"
              )}
              onClick={() => onNumberClick(num)}
            >
              {num}
              {isCompleted && (
                <div className="absolute -top-1 -right-1 bg-primary rounded-full p-0.5 shadow-lg">
                  <Check className="w-2.5 h-2.5 text-white" />
                </div>
              )}
            </Button>
          )
        })}
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Button
          variant={isNotesMode ? "default" : "outline"}
          className={cn(
            "flex-col h-24 gap-2 rounded-[2rem] border-white/10 glass transition-all duration-500",
            isNotesMode && "bg-primary text-white border-transparent shadow-[0_0_30px_rgba(37,99,235,0.3)]"
          )}
          onClick={onToggleNotes}
        >
          <Pencil className="h-6 w-6" />
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold">Notes</span>
        </Button>
        
        <Button
          variant="outline"
          className="flex-col h-24 gap-2 rounded-[2rem] border-white/10 glass hover:bg-destructive/10 hover:text-destructive transition-all duration-300"
          onClick={onErase}
        >
          <Eraser className="h-6 w-6" />
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold">Erase</span>
        </Button>

        <Button
          variant="outline"
          className="flex-col h-24 gap-2 rounded-[2rem] border-white/10 glass hover:bg-white/5 transition-all duration-300"
          onClick={onHint}
        >
          <Lightbulb className="h-6 w-6 text-yellow-400" />
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold">Hint</span>
        </Button>

        <Button
          variant="outline"
          className="flex-col h-24 gap-2 rounded-[2rem] border-white/10 glass group relative overflow-hidden"
          onClick={onExplain}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <Sparkles className="h-6 w-6 relative z-10 text-primary animate-float" />
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold relative z-10">Explain</span>
        </Button>
      </div>
    </div>
  )
}
