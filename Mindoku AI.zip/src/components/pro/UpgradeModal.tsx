"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Check, Crown, Star, Zap, BrainCircuit } from "lucide-react"

interface UpgradeModalProps {
  isOpen: boolean
  onClose: () => void
}

export function UpgradeModal({ isOpen, onClose }: UpgradeModalProps) {
  const features = [
    { title: "Unlimited AI Coaching", desc: "Deeper logical explanations for every cell.", icon: <BrainCircuit className="w-5 h-5" /> },
    { title: "Focus Analytics", desc: "Detailed concentration reports and heatmaps.", icon: <Zap className="w-5 h-5" /> },
    { title: "Premium Themes", desc: "Glassmorphism, OLED Dark, and Zen modes.", icon: <Star className="w-5 h-5" /> },
    { title: "Cloud Sync", desc: "Sync your progress across all your Apple devices.", icon: <Crown className="w-5 h-5" /> },
  ]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card border-white/10 max-w-lg p-0 overflow-hidden sm:rounded-[2.5rem]">
        <div className="bg-gradient-to-br from-primary/20 to-purple-500/20 p-8 text-center space-y-4">
          <div className="inline-flex p-4 rounded-full bg-white/10 backdrop-blur-xl mb-4">
            <Crown className="w-10 h-10 text-primary" />
          </div>
          <DialogTitle className="text-3xl font-headline font-bold text-gradient">Elevate Your Mind</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Join 10,000+ focused minds and unlock the full potential of Mindoku Pro.
          </DialogDescription>
        </div>
        
        <div className="p-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {features.map((f, i) => (
              <div key={i} className="flex gap-3 items-start">
                <div className="p-2 rounded-xl bg-white/5 text-primary shrink-0">
                  {f.icon}
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-bold">{f.title}</p>
                  <p className="text-xs text-muted-foreground leading-tight">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4 space-y-4">
            <Button className="w-full apple-button bg-primary text-white text-lg h-14 shadow-lg shadow-primary/20">
              Start 7-Day Free Trial
            </Button>
            <p className="text-center text-[10px] text-muted-foreground uppercase tracking-widest">
              Then $4.99/month. Cancel anytime.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
