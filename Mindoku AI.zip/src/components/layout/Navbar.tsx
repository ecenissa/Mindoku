"use client"

import { Button } from "@/components/ui/button"
import { Trophy, Flame, Crown, Bell } from "lucide-react"

interface NavbarProps {
  onUpgradeClick?: () => void
}

export function Navbar({ onUpgradeClick }: NavbarProps) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass h-20 px-8 flex items-center justify-between border-b-0">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary to-blue-400 flex items-center justify-center shadow-lg shadow-primary/20 animate-float">
          <span className="font-headline font-bold text-white text-xl">M</span>
        </div>
        <span className="font-headline font-bold text-2xl tracking-tighter hidden sm:inline-block text-gradient">Mindoku</span>
      </div>

      <div className="flex items-center gap-3 sm:gap-6">
        <div className="hidden md:flex items-center gap-6 px-6 py-2 rounded-full glass bg-white/[0.02]">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-orange-400" />
            <span className="text-sm font-bold tracking-tight">12 Days</span>
          </div>
          <div className="w-px h-4 bg-white/10" />
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span className="text-sm font-bold tracking-tight">Lvl 4</span>
          </div>
        </div>

        <Button 
          variant="outline" 
          size="icon" 
          className="rounded-full glass border-white/10 hover:bg-white/5"
        >
          <Bell className="w-4 h-4 opacity-70" />
        </Button>

        <Button 
          onClick={onUpgradeClick}
          className="apple-button bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 hidden sm:flex gap-2"
        >
          <Crown className="w-4 h-4" />
          <span>Pro</span>
        </Button>

        <div className="w-10 h-10 rounded-full border border-white/10 overflow-hidden cursor-pointer hover:ring-2 ring-primary transition-all p-0.5 bg-white/5">
          <img src="https://picsum.photos/seed/mindoku-user/100/100" alt="Avatar" className="w-full h-full rounded-full object-cover" />
        </div>
      </div>
    </nav>
  )
}
