"use client"

import { useEffect, useState } from "react"
import { getMotivationalMessage } from "@/ai/flows/ai-motivational-coach"
import { Sparkles, X, BrainCircuit, Quote, Loader2, ChevronRight, MessageSquare, Maximize2, Minimize2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface AICoachPanelProps {
  explanation?: string
  onCloseExplanation?: () => void
}

export function AICoachPanel({ explanation, onCloseExplanation }: AICoachPanelProps) {
  const [motivation, setMotivation] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const fetchMotivation = async () => {
      setIsLoading(true)
      try {
        const res = await getMotivationalMessage()
        setMotivation(res.message)
      } catch (err) {
        setMotivation("Focus on the geometric patterns. Each deduction brings you closer to mental clarity.")
      } finally {
        setIsLoading(false)
      }
    }
    fetchMotivation()
    const interval = setInterval(fetchMotivation, 300000)
    return () => clearInterval(interval)
  }, [])

  if (!isVisible) return (
    <div className="fixed bottom-6 right-6 z-50 pointer-events-auto animate-in fade-in zoom-in duration-500">
      <Button 
        variant="outline" 
        size="icon" 
        onClick={() => setIsVisible(true)}
        className="h-12 w-12 rounded-full glass border-primary/20 bg-primary/5 text-primary shadow-2xl hover:bg-primary/10 transition-all hover:scale-110"
      >
        <Sparkles className="w-5 h-5" />
      </Button>
    </div>
  )

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-4 w-full max-w-sm pointer-events-none">
      {/* Logic Synthesis / Explanation Panel */}
      {explanation && (
        <div className="glass-card p-8 rounded-[2rem] border-primary/20 pointer-events-auto w-full animate-in slide-in-from-bottom-8 fade-in duration-500 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-primary/10 text-primary">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary">Synthesis</span>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-white/5" onClick={onCloseExplanation}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <ScrollArea className="max-h-60 pr-4">
            <p className="text-lg leading-relaxed text-foreground/90 font-medium font-headline tracking-tight">
              {explanation}
            </p>
          </ScrollArea>
        </div>
      )}

      {/* Motivation Bubble */}
      <div className={cn(
        "glass rounded-[2rem] border-white/10 shadow-2xl pointer-events-auto transition-all duration-700 ease-apple-ease relative overflow-hidden group",
        isMinimized ? "w-14 h-14 p-0 rounded-full" : "w-full max-w-[280px] p-5"
      )}>
        {isMinimized ? (
          <button 
            onClick={() => setIsMinimized(false)}
            className="w-full h-full flex items-center justify-center text-primary relative"
          >
            <div className="absolute inset-0 bg-primary/5 animate-pulse" />
            <Sparkles className="w-5 h-5 relative z-10" />
          </button>
        ) : (
          <div className="space-y-4 animate-in fade-in duration-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 text-primary">
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Quote className="w-4 h-4" />}
                <span className="text-[9px] uppercase tracking-[0.2em] font-bold text-muted-foreground/60">Insight</span>
              </div>
              <div className="flex items-center gap-1">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-6 w-6 rounded-md hover:bg-white/5 opacity-40 hover:opacity-100"
                  onClick={() => setIsMinimized(true)}
                >
                  <Minimize2 className="h-3 w-3" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-6 w-6 rounded-md hover:bg-white/5 opacity-40 hover:opacity-100"
                  onClick={() => setIsVisible(false)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
            
            <p className="text-xs text-foreground/80 leading-relaxed font-medium">
              {isLoading && !motivation ? "Synthesizing..." : motivation || "Focus builds clarity."}
            </p>

            {isLoading && (
              <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-white/5">
                <div className="h-full bg-primary animate-[shimmer_2s_infinite]" style={{ width: '40%' }} />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
