import { config } from 'dotenv';
config();

import '@/ai/flows/ai-error-explanation.ts';
import '@/ai/flows/ai-motivational-coach.ts';
import '@/ai/flows/ai-smart-hint.ts';
import '@/ai/flows/ai-reflection.ts';
