'use server';
/**
 * @fileOverview An AI motivational coach that provides short, focus-oriented messages.
 *
 * - getMotivationalMessage - A function that fetches a motivational message from the AI coach.
 * - AIMotivationalCoachInput - The input type for the getMotivationalMessage function.
 * - AIMotivationalCoachOutput - The return type for the getMotivationalMessage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIMotivationalCoachInputSchema = z.object({
  // Currently, no specific input context is required for generic motivational messages.
  // This can be extended to include game state if context-aware messages are needed in the future.
}).describe('Input schema for the AI Motivational Coach. Currently, it does not require any specific input context.');
export type AIMotivationalCoachInput = z.infer<typeof AIMotivationalCoachInputSchema>;

const AIMotivationalCoachOutputSchema = z.object({
  message: z.string().describe('A short, motivational, and focus-oriented message.'),
}).describe('Output schema for the AI Motivational Coach, containing a motivational message.');
export type AIMotivationalCoachOutput = z.infer<typeof AIMotivationalCoachOutputSchema>;

/**
 * Fetches a motivational message from the AI coach.
 * @param input - The input for the motivational coach (currently empty).
 * @returns A promise that resolves to an AIMotivationalCoachOutput object containing a motivational message.
 */
export async function getMotivationalMessage(input: AIMotivationalCoachInput = {}): Promise<AIMotivationalCoachOutput> {
  return aiMotivationalCoachFlow(input);
}

const motivationalCoachPrompt = ai.definePrompt({
  name: 'motivationalCoachPrompt',
  input: {schema: AIMotivationalCoachInputSchema},
  output: {schema: AIMotivationalCoachOutputSchema},
  prompt: `You are an AI motivational coach for a Sudoku and focus training app called Mindoku. Your goal is to provide short, encouraging, and focus-reinforcing messages to the user during their sessions. The user is currently engaged in a brain-training activity.

Generate a single, concise motivational message. The message should inspire focus and perseverance.

Example: 'Stay sharp, your focus is your greatest asset!'
Example: 'Every digit counts! Deep concentration builds mastery.'
Example: 'Embrace the challenge, unlock your potential.'

Generate message:`,
});

const aiMotivationalCoachFlow = ai.defineFlow(
  {
    name: 'aiMotivationalCoachFlow',
    inputSchema: AIMotivationalCoachInputSchema,
    outputSchema: AIMotivationalCoachOutputSchema,
  },
  async input => {
    const {output} = await motivationalCoachPrompt(input);
    if (!output) {
      throw new Error('Failed to generate a motivational message.');
    }
    return output;
  }
);
