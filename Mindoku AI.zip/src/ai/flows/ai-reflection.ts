'use server';
/**
 * @fileOverview A Genkit flow that generates a cognitive reflection after a Sudoku puzzle.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AIReflectionInputSchema = z.object({
  timeInSeconds: z.number(),
  mistakes: z.number(),
  hintsUsed: z.number(),
  difficulty: z.string(),
  averageRhythmSeconds: z.number().describe('Average time between correct moves.'),
});
export type AIReflectionInput = z.infer<typeof AIReflectionInputSchema>;

const AIReflectionOutputSchema = z.object({
  archetype: z.enum(['The Strategist', 'The Analyst', 'The Visionary', 'The Flow Thinker']),
  reflection: z.string().describe('A calming, intelligent, and wellness-oriented reflection on the user\'s focus patterns.'),
  focusScore: z.number().min(0).max(100),
  insight: z.string().describe('A single short sentence about cognitive growth.'),
});
export type AIReflectionOutput = z.infer<typeof AIReflectionOutputSchema>;

export async function generateReflection(input: AIReflectionInput): Promise<AIReflectionOutput> {
  return aiReflectionFlow(input);
}

const aiReflectionPrompt = ai.definePrompt({
  name: 'aiReflectionPrompt',
  input: { schema: AIReflectionInputSchema },
  output: { schema: AIReflectionOutputSchema },
  prompt: `You are a cognitive focus coach for Mindoku, a wellness-oriented brain training platform. 
Analyze the following session data and provide a calming, intelligent, and sophisticated reflection.

Session Data:
- Difficulty: {{difficulty}}
- Time: {{timeInSeconds}}s
- Mistakes: {{mistakes}}
- Hints Used: {{hintsUsed}}
- Solving Rhythm: {{averageRhythmSeconds}}s per move

Archetype Guidelines:
- The Strategist: Low mistakes, low hints, steady rhythm.
- The Analyst: High notes usage (implied by slow but accurate rhythm), meticulous.
- The Visionary: Fast pace, high rhythm consistency, possibly a few intuitive mistakes.
- The Flow Thinker: Very consistent rhythm, moderate speed.

Generate a reflection that feels like a premium wellness app (e.g., Calm or Headspace but for productivity). Use a sophisticated, encouraging tone.`,
});

const aiReflectionFlow = ai.defineFlow(
  {
    name: 'aiReflectionFlow',
    inputSchema: AIReflectionInputSchema,
    outputSchema: AIReflectionOutputSchema,
  },
  async (input) => {
    const { output } = await aiReflectionPrompt(input);
    if (!output) throw new Error('Failed to generate reflection');
    return output;
  }
);
