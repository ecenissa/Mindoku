'use server';
/**
 * @fileOverview This file implements a Genkit flow for explaining why a given Sudoku number is incorrect.
 *
 * - explainIncorrectNumber - A function that requests an explanation from the AI for an incorrect Sudoku entry.
 * - ExplainIncorrectNumberInput - The input type for the explainIncorrectNumber function.
 * - ExplainIncorrectNumberOutput - The return type for the explainIncorrectNumber function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExplainIncorrectNumberInputSchema = z.object({
  board: z
    .array(z.array(z.number()))
    .describe('The current state of the Sudoku board, where 0 represents an empty cell.'),
  row: z.number().int().min(0).max(8).describe('The 0-indexed row of the incorrect number.'),
  col: z.number().int().min(0).max(8).describe('The 0-indexed column of the incorrect number.'),
  number: z
    .number()
    .int()
    .min(1)
    .max(9)
    .describe('The incorrect number entered by the user.'),
});
export type ExplainIncorrectNumberInput = z.infer<
  typeof ExplainIncorrectNumberInputSchema
>;

const ExplainIncorrectNumberOutputSchema = z.object({
  explanation: z.string().describe('A detailed explanation of why the number is incorrect.'),
});
export type ExplainIncorrectNumberOutput = z.infer<
  typeof ExplainIncorrectNumberOutputSchema
>;

export async function explainIncorrectNumber(
  input: ExplainIncorrectNumberInput
): Promise<ExplainIncorrectNumberOutput> {
  return explainIncorrectNumberFlow(input);
}

const explainIncorrectNumberPrompt = ai.definePrompt({
  name: 'explainIncorrectNumberPrompt',
  input: {schema: ExplainIncorrectNumberInputSchema},
  output: {schema: ExplainIncorrectNumberOutputSchema},
  prompt: `You are a Sudoku expert and a helpful coach. A player has entered the number '{{{number}}}' at row '{{{row}}}', column '{{{col}}}'. This number is incorrect based on the current board state.

Your task is to explain in detail, and in a coaching tone, why this specific number is incorrect according to the rules of Sudoku. Do not just state it's wrong, but clearly identify which other numbers in the same row, column, or 3x3 block conflict with it. Provide actionable insights on how the player can identify such mistakes.

Sudoku Rules Reminder:
1. Each row must contain the digits 1-9 without repetition.
2. Each column must contain the digits 1-9 without repetition.
3. Each of the nine 3x3 subgrids must contain the digits 1-9 without repetition.

Current Sudoku Board (0 indicates an empty cell):
{{{board}}}

Incorrect Entry: Number '{{{number}}}' at Row '{{{row}}}', Column '{{{col}}}'.`,
});

const explainIncorrectNumberFlow = ai.defineFlow(
  {
    name: 'explainIncorrectNumberFlow',
    inputSchema: ExplainIncorrectNumberInputSchema,
    outputSchema: ExplainIncorrectNumberOutputSchema,
  },
  async input => {
    const {output} = await explainIncorrectNumberPrompt(input);
    return output!;
  }
);
