'use server';
/**
 * @fileOverview A Genkit flow that provides smart, non-direct hints for Sudoku puzzles.
 *
 * - aiSmartHint - A function that generates a smart Sudoku hint.
 * - AiSmartHintInput - The input type for the aiSmartHint function.
 * - AiSmartHintOutput - The return type for the aiSmartHint function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AiSmartHintInputSchema = z.object({
  board: z.array(z.array(z.number().min(0).max(9))).length(9).describe('The current state of the Sudoku board, where 0 represents an empty cell.'),
  difficulty: z.enum(['easy', 'medium', 'hard', 'expert']).describe('The difficulty level of the Sudoku puzzle.'),
});
export type AiSmartHintInput = z.infer<typeof AiSmartHintInputSchema>;

const AiSmartHintOutputSchema = z.object({
  hint: z.string().describe('A smart, non-direct hint about a potential next step or strategy to solve the Sudoku puzzle. Focus on guiding the user to learn, not just giving the answer.'),
});
export type AiSmartHintOutput = z.infer<typeof AiSmartHintOutputSchema>;

// Internal schema for the prompt, including the formatted board
const AiSmartHintPromptInternalInputSchema = z.object({
  formattedBoard: z.string().describe('A nicely formatted string representation of the Sudoku board.'),
  difficulty: z.enum(['easy', 'medium', 'hard', 'expert']).describe('The difficulty level of the Sudoku puzzle.'),
});

const aiSmartHintPrompt = ai.definePrompt({
  name: 'aiSmartHintPrompt',
  input: { schema: AiSmartHintPromptInternalInputSchema },
  output: { schema: AiSmartHintOutputSchema },
  prompt: `You are an AI Sudoku coach. Your goal is to help a player learn and improve their Sudoku skills by providing smart, non-direct hints.
Do NOT give away the exact number for any cell or tell the player to fill a specific cell with a specific number. Instead, guide them with strategies, thought processes, or areas to focus on.

Consider the current state of the Sudoku board and its difficulty.

Current Sudoku Board (0 means empty cell):
{{formattedBoard}}

Difficulty: {{difficulty}}

Based on this, provide a non-direct hint to help the player progress. Focus on general strategies like "look for single candidates in rows/columns/blocks", "check for hidden singles", "consider pairs", or "focus on areas with fewer empty cells". Encourage logical deduction.

Example: "Try looking at rows or columns that have many numbers already filled in. Often, these are good starting points to find missing digits."

Your hint:`,
});

const aiSmartHintFlow = ai.defineFlow(
  {
    name: 'aiSmartHintFlow',
    inputSchema: AiSmartHintInputSchema,
    outputSchema: AiSmartHintOutputSchema,
  },
  async (input) => {
    // Format the board for better readability by the LLM
    const formattedBoard = input.board.map(row =>
      row.map(cell => (cell === 0 ? '_' : cell)).join(' ')
    ).join('\n');

    const { output } = await aiSmartHintPrompt({
      formattedBoard,
      difficulty: input.difficulty,
    });
    if (!output) {
      throw new Error('Failed to generate hint.');
    }
    return output;
  }
);

export async function aiSmartHint(input: AiSmartHintInput): Promise<AiSmartHintOutput> {
  return aiSmartHintFlow(input);
}
