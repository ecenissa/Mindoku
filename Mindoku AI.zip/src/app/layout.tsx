import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Mindoku | AI-Powered Focus Training',
  description: 'Elevate your mind with modern Sudoku and AI-driven cognitive coaching.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased min-h-screen selection:bg-primary/30 selection:text-primary">
        {children}
      </body>
    </html>
  );
}
