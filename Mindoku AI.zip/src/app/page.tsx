"use client"

import { useState, useEffect, useCallback, useMemo, useRef } from "react"
import { Navbar } from "@/components/layout/Navbar"
import { SudokuBoard } from "@/components/sudoku/SudokuBoard"
import { GameControls } from "@/components/sudoku/GameControls"
import { AICoachPanel } from "@/components/ai/AICoachPanel"
import { Onboarding } from "@/components/onboarding/Onboarding"
import { StatsDashboard } from "@/components/dashboard/StatsDashboard"
import { UpgradeModal } from "@/components/pro/UpgradeModal"
import { VictoryReflection } from "@/components/victory/VictoryReflection"
import { generateSudoku, Difficulty, isBoardComplete, getConflicts, getNumberCounts } from "@/lib/sudoku-utils"
import { explainIncorrectNumber } from "@/ai/flows/ai-error-explanation"
import { aiSmartHint } from "@/ai/flows/ai-smart-hint"
import { generateReflection, type AIReflectionOutput } from "@/ai/flows/ai-reflection"
import { useToast } from "@/hooks/use-toast"
import { Timer, Zap, ChevronDown, CheckCircle2, LayoutDashboard, Gamepad2, Star, Target, Trophy, ArrowRight, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

export default function MindokuApp() {
  const [view, setView] = useState<'onboarding' | 'dashboard' | 'game'>('onboarding')
  const [board, setBoard] = useState<number[][]>([])
  const [initialBoard, setInitialBoard] = useState<number[][]>([])
  const [solvedBoard, setSolvedBoard] = useState<number[][]>([])
  const [notes, setNotes] = useState<Set<number>[][]>([])
  const [difficulty, setDifficulty] = useState<Difficulty>('medium')
  const [selectedCell, setSelectedCell] = useState<[number, number] | null>(null)
  const [isNotesMode, setIsNotesMode] = useState(false)
  const [timer, setTimer] = useState(0)
  const [mistakes, setMistakes] = useState(0)
  const [hintsUsed, setHintsUsed] = useState(0)
  const [isGameWon, setIsGameWon] = useState(false)
  const [aiExplanation, setAiExplanation] = useState<string | undefined>()
  const [isProModalOpen, setIsProModalOpen] = useState(false)
  
  // Reflection State
  const [reflection, setReflection] = useState<AIReflectionOutput | null>(null)
  const [isGeneratingReflection, setIsGeneratingReflection] = useState(false)
  const moveTimestamps = useRef<number[]>([])

  const { toast } = useToast()

  const numberCounts = useMemo(() => {
    if (!board || board.length === 0) {
      const empty: Record<number, number> = {};
      for (let i = 1; i <= 9; i++) empty[i] = 0;
      return empty;
    }
    return getNumberCounts(board, initialBoard);
  }, [board, initialBoard]);

  const startNewGame = useCallback((diff: Difficulty = 'medium') => {
    const { initial, solved } = generateSudoku(diff)
    setBoard(initial.map(row => [...row]))
    setInitialBoard(initial.map(row => [...row]))
    setSolvedBoard(solved)
    setNotes(Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => new Set())))
    setTimer(0)
    setMistakes(0)
    setHintsUsed(0)
    setIsGameWon(false)
    setReflection(null)
    setAiExplanation(undefined)
    setSelectedCell(null)
    setDifficulty(diff)
    setView('game')
    moveTimestamps.current = [Date.now()]
  }, [])

  useEffect(() => {
    const hasOnboarded = localStorage.getItem('mindoku_onboarded')
    if (hasOnboarded) setView('dashboard')
  }, [])

  useEffect(() => {
    if (view !== 'game' || isGameWon) return
    const interval = setInterval(() => setTimer(t => t + 1), 1000)
    return () => clearInterval(interval)
  }, [view, isGameWon])

  const handleVictory = useCallback(async () => {
    setIsGameWon(true)
    setIsGeneratingReflection(true)
    
    const intervals: number[] = []
    for (let i = 1; i < moveTimestamps.current.length; i++) {
      intervals.push((moveTimestamps.current[i] - moveTimestamps.current[i-1]) / 1000)
    }
    const avgRhythm = intervals.length > 0 ? intervals.reduce((a, b) => a + b) / intervals.length : 0

    try {
      const res = await generateReflection({
        timeInSeconds: timer,
        mistakes,
        hintsUsed,
        difficulty,
        averageRhythmSeconds: avgRhythm
      })
      setReflection(res)
    } catch (err) {
      console.error(err)
    } finally {
      setIsGeneratingReflection(false)
    }
  }, [timer, mistakes, hintsUsed, difficulty])

  const handleNumberInput = (num: number) => {
    if (!selectedCell || isGameWon || !board.length) return
    const [r, c] = selectedCell
    if (initialBoard[r][c] !== 0) return

    if (isNotesMode) {
      const newNotes = [...notes]
      const cellNotes = new Set(newNotes[r][c])
      if (cellNotes.has(num)) cellNotes.delete(num)
      else cellNotes.add(num)
      newNotes[r][c] = cellNotes
      setNotes(newNotes)
    } else {
      const newBoard = board.map(row => [...row])
      newBoard[r][c] = num
      setBoard(newBoard)
      
      moveTimestamps.current.push(Date.now())

      const conflicts = getConflicts(newBoard, r, c, num)
      if (conflicts.length > 0) {
        setMistakes(m => m + 1)
      }

      if (isBoardComplete(newBoard) && getConflicts(newBoard, -1, -1, -1).length === 0) {
        handleVictory()
      }
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  if (view === 'onboarding') return <Onboarding onComplete={() => {
    localStorage.setItem('mindoku_onboarded', 'true')
    setView('dashboard')
  }} />

  return (
    <div className="min-h-screen pt-28 pb-12 px-6 max-w-[1400px] mx-auto overflow-x-hidden selection:bg-primary/20">
      <Navbar onUpgradeClick={() => setIsProModalOpen(true)} />
      
      <div className="space-y-16 animate-slide-up">
        <div className="flex justify-center">
          <Tabs value={view} onValueChange={(v) => setView(v as any)} className="glass rounded-full p-1 border-white/5 shadow-2xl">
            <TabsList className="bg-transparent gap-1 h-auto">
              <TabsTrigger value="dashboard" className="rounded-full px-8 py-2.5 data-[state=active]:bg-white data-[state=active]:text-black data-[state=active]:shadow-xl transition-all font-medium">
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Dashboard
              </TabsTrigger>
              <TabsTrigger value="game" className="rounded-full px-8 py-2.5 data-[state=active]:bg-white data-[state=active]:text-black data-[state=active]:shadow-xl transition-all font-medium">
                <Gamepad2 className="w-4 h-4 mr-2" />
                Training
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {view === 'dashboard' ? (
          <div className="max-w-6xl mx-auto">
            <StatsDashboard />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
            <div className="lg:col-span-3 space-y-8 hidden lg:block">
              <div className="glass-card p-10">
                <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-muted-foreground mb-8 opacity-60">Session Metrics</h3>
                <div className="space-y-10">
                  <div className="flex justify-between items-end group">
                    <div className="space-y-1.5">
                      <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-bold">Time</p>
                      <p className="text-3xl font-headline font-bold tracking-tight">{formatTime(timer)}</p>
                    </div>
                    <Timer className="w-6 h-6 text-primary opacity-30 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="flex justify-between items-end group">
                    <div className="space-y-1.5">
                      <p className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-bold">Mistakes</p>
                      <p className={cn("text-3xl font-headline font-bold tracking-tight", mistakes > 0 ? "text-destructive" : "text-primary")}>
                        {mistakes}
                      </p>
                    </div>
                    <Target className="w-6 h-6 text-destructive opacity-30 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
              </div>

              <div className="glass-card p-10 bg-primary/5 border-primary/10 overflow-hidden relative">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <Zap className="w-12 h-12 text-primary" />
                </div>
                <div className="flex items-center gap-2 mb-6">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary">Live Pulse</span>
                </div>
                <p className="text-sm leading-relaxed text-foreground/80 font-medium">
                  {mistakes === 0 ? "Perfect focus maintained. Your cognitive rhythm is exceptionally stable." : "Resilience check: Minor deviation detected. Re-center on the current block."}
                </p>
              </div>
            </div>

            <div className="lg:col-span-6 flex flex-col items-center">
              <div className="w-full max-w-[500px] mb-12 flex items-center justify-between">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="p-0 h-auto font-headline text-4xl font-bold hover:bg-transparent tracking-tighter text-gradient">
                      {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                      <ChevronDown className="ml-3 w-8 h-8 opacity-20" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="glass border-white/10 rounded-[1.5rem] p-2 min-w-[200px] shadow-2xl">
                    <DropdownMenuItem className="rounded-xl px-4 py-3 font-medium cursor-pointer" onClick={() => startNewGame('easy')}>Easy</DropdownMenuItem>
                    <DropdownMenuItem className="rounded-xl px-4 py-3 font-medium cursor-pointer" onClick={() => startNewGame('medium')}>Medium</DropdownMenuItem>
                    <DropdownMenuItem className="rounded-xl px-4 py-3 font-medium cursor-pointer" onClick={() => startNewGame('hard')}>Hard</DropdownMenuItem>
                    <DropdownMenuItem className="rounded-xl px-4 py-3 font-medium cursor-pointer" onClick={() => startNewGame('expert')}>Expert</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <Button onClick={() => startNewGame(difficulty)} variant="outline" className="apple-button h-11 border-white/10 text-[10px] font-bold uppercase tracking-widest bg-white/[0.02] hover:bg-white/[0.05]">
                  Restart
                </Button>
              </div>

              {board.length > 0 && (
                <SudokuBoard 
                  board={board} 
                  initialBoard={initialBoard}
                  notes={notes}
                  selectedCell={selectedCell}
                  onCellClick={(r, c) => setSelectedCell([r, c])}
                />
              )}

              {board.length > 0 && (
                <GameControls 
                  isNotesMode={isNotesMode}
                  onToggleNotes={() => setIsNotesMode(!isNotesMode)}
                  onNumberClick={handleNumberInput}
                  numberCounts={numberCounts}
                  onErase={() => {
                    if (!selectedCell || isGameWon) return
                    const [r, c] = selectedCell
                    if (initialBoard[r][c] !== 0) return
                    const newBoard = board.map(row => [...row])
                    newBoard[r][c] = 0
                    setBoard(newBoard)
                    const newNotes = [...notes]
                    newNotes[r][c] = new Set()
                    setNotes(newNotes)
                  }}
                  onHint={async () => {
                    setHintsUsed(h => h + 1)
                    const { dismiss } = toast({ title: "Neural Sync", description: "Mapping logical pathways..." })
                    try {
                      const res = await aiSmartHint({ board, difficulty })
                      setAiExplanation(res.hint)
                      dismiss()
                    } catch (err) {
                      dismiss()
                      toast({ 
                        variant: "destructive",
                        title: "System Latency", 
                        description: "AI nodes are re-balancing. Please try again." 
                      })
                    }
                  }}
                  onExplain={async () => {
                    if (!selectedCell) return
                    const [r, c] = selectedCell
                    const num = board[r][c]
                    if (num === 0) return
                    const { dismiss } = toast({ title: "Synthesizing Logic", description: "Evaluating block constraints..." })
                    try {
                      const res = await explainIncorrectNumber({ board, row: r, col: c, number: num })
                      setAiExplanation(res.explanation)
                      dismiss()
                    } catch (err) {
                      dismiss()
                      toast({ 
                        variant: "destructive",
                        title: "Synthesis Failed", 
                        description: "The logic engine is unavailable. Retry shortly." 
                      })
                    }
                  }}
                  onReset={() => startNewGame(difficulty)}
                />
              )}
            </div>

            <div className="lg:col-span-3 space-y-8 hidden lg:block">
              <div className="glass-card p-10 bg-gradient-to-br from-primary/15 to-transparent border-primary/20 shadow-xl shadow-primary/5">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
                    <Trophy className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="text-lg font-headline font-bold tracking-tight">Mastery Index</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-10 leading-relaxed font-medium">
                  Your cognitive retention is trending upward. Complete this session to lock in 500 focus pts.
                </p>
                <Button onClick={() => setIsProModalOpen(true)} className="w-full apple-button bg-primary text-white font-bold h-14 shadow-2xl shadow-primary/20 hover:scale-[1.02]">
                  Join Mindoku Pro
                </Button>
              </div>
              
              <div className="space-y-6">
                <h4 className="text-[10px] uppercase tracking-[0.4em] font-bold text-muted-foreground/40 px-2">Digit Mastery</h4>
                <div className="grid grid-cols-3 gap-3">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                    <div key={num} className={cn(
                      "glass rounded-2xl p-4 flex flex-col items-center gap-2 transition-all",
                      numberCounts[num] >= 9 ? "bg-primary/20 border-primary/30" : "opacity-40"
                    )}>
                      <span className="text-xl font-headline font-bold">{num}</span>
                      <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary transition-all duration-1000" 
                          style={{ width: `${(numberCounts[num] / 9) * 100}%` }} 
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <AICoachPanel 
        explanation={aiExplanation} 
        onCloseExplanation={() => setAiExplanation(undefined)} 
      />

      <UpgradeModal isOpen={isProModalOpen} onClose={() => setIsProModalOpen(false)} />

      {isGameWon && (
        <VictoryReflection 
          timer={timer}
          mistakes={mistakes}
          difficulty={difficulty}
          reflection={reflection}
          isLoading={isGeneratingReflection}
          onRestart={() => startNewGame(difficulty)}
          onDashboard={() => setView('dashboard')}
        />
      )}
    </div>
  )
}
