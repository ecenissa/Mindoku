# **App Name**: Mindoku

## Core Features:

- Playable Sudoku Game: A fully functional Sudoku board with easy, medium, and hard difficulty levels. Includes a timer and restart/reset game functionality.
- Interactive Input Tools: Features a notes mode for planning moves and an instant mistake checker to validate entries.
- AI Guided Assistance: An AI tool that can provide smart hints or explain why a particular number is wrong, guiding users towards the solution without just giving answers.
- AI Motivational Coach: An AI tool that provides motivational focus messages throughout the game to enhance the brain training and self-development experience.
- Focus Streak Tracking: Keeps track of daily focus streaks to encourage consistent practice and highlight user progress in focus improvement.
- Victory Animation: A smooth, rewarding animation upon completing a Sudoku puzzle to enhance the user's sense of achievement.

## Style Guidelines:

- Primary accent color: A sophisticated, muted blue (#8FC5FF) to highlight interactive elements and draw focus, evoking calmness and productivity in a dark scheme.
- Background color: A very dark charcoal blue (#161A1C) serving as a calming and professional backdrop for the premium dark mode experience.
- Secondary accent color: A bright cyan (#4CD4FF) for subtle calls to action or supplementary information, providing dynamic contrast to the primary.
- Headline font: 'Space Grotesk' (sans-serif) for a modern, tech-savvy, and sharp appearance.
- Body font: 'Inter' (sans-serif) for clean readability and a neutral, objective feel suitable for detailed information and guidance.
- Use minimalist, crisp line icons with a subtle glassmorphic effect, mirroring an Apple-inspired UI, focusing on clarity and elegance.
- Employ a responsive, glassmorphic card-based design with generous darkspace, creating a premium and focused user experience across all devices.
- Integrate smooth, subtle animations for state changes, navigation, and user feedback, enhancing the interactive 'premium startup' feel.